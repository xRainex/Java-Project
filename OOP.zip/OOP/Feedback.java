/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package OOP;
import java.io.File;
import java.util.Iterator;
import org.json.JSONArray;
import org.json.JSONObject;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;


 

public class Feedback extends javax.swing.JFrame {

     
    public Feedback() {
        initComponents();
        loadAppointments();
    }
    
    
    
    private void loadAppointments() {
     DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
    model.setRowCount(0); // Clear the table before loading new data

    // Set row height for better visibility
    jTable1.setRowHeight(50);
    jTable1.getModel().addTableModelListener(e -> {
    if (e.getType() == javax.swing.event.TableModelEvent.UPDATE) {
        int row = e.getFirstRow();
        int column = e.getColumn();

        String date = jTable1.getValueAt(row, 1).toString();
        String time = jTable1.getValueAt(row, 2).toString();
        String updatedFeedback = jTable1.getValueAt(row, column).toString();

        updateFeedbackInFile(date, time, column, updatedFeedback);
    }
});

    
    
    try {
        // Ensure the file exists
        File file = new File("appointment.txt");
        if (!file.exists()) {
            file.createNewFile();
            System.out.println("New file created: " + file.getName());
        }

        // Read the appointment file
        String appointDatabase = new String(Files.readAllBytes(Paths.get("appointment.txt")));
        JSONObject appointJson = new JSONObject(appointDatabase.isEmpty() ? "{}" : appointDatabase);

        // Iterate over all keys in the JSON object
        Iterator<String> appointKeys = appointJson.keys();

        while (appointKeys.hasNext()) {
            String appointID = appointKeys.next(); // Appointment ID as key
            JSONArray appointArray = appointJson.getJSONArray(appointID);

            // Iterate through each appointment record
            for (int i = 0; i < appointArray.length(); i++) {
                JSONObject appointData = appointArray.getJSONObject(i);

                // Check if the status is "Completed"
                String status = appointData.optString("status", ""); // Optional status field
                if (!"Completed".equalsIgnoreCase(status)) {
                    continue; // Skip non-completed appointments
                }

                // Extract appointment details
                String date = appointData.getString("date");
                String time = appointData.getString("time");
                String duration = appointData.getString("duration");
                String lecturerFeedback = appointData.optString("lecturerFeedback", "No feedback yet");
                String studentFeedback = appointData.optString("studentFeedback", "No feedback yet");

                // Logic for filtering based on user role
                if (Details.userRole.equals("student") && appointData.getString("studentId").equals(Details.userId)) {
                    String lecturerName = appointData.getString("lecturerName");
                    model.addRow(new Object[]{
                    "Lecturer: " + lecturerName,
                    date,
                    time,
                    duration,
                    lecturerFeedback,
                    studentFeedback
                });

                } else if (Details.userRole.equals("lecturer") && appointData.getString("lecturerId").equals(Details.userId)) {
                    String studentName = appointData.optString("studentName", "Unknown");
                    model.addRow(new Object[]{
                    "Student: " + studentName,
                    date,
                    time,
                    duration,
                    lecturerFeedback,
                    studentFeedback
                });
                }
            }
        }
    } catch (IOException e) {
        System.out.println("Error: " + e.getMessage());
        JOptionPane.showMessageDialog(this, "Error reading the appointments file.");
    }
}


    
    private void leaveFeedbackActionPerformed() {
    int selectedRow = jTable1.getSelectedRow();
    if (selectedRow != -1) {
        try {
            // Get the details of the selected row
            String name = jTable1.getValueAt(selectedRow, 0).toString();
            String date = jTable1.getValueAt(selectedRow, 1).toString();
            String time = jTable1.getValueAt(selectedRow, 2).toString();
            String feedbackInput = JOptionPane.showInputDialog(this, "Enter your feedback for " + name);

            if (feedbackInput != null && !feedbackInput.trim().isEmpty()) {
                // Read the appointment file
                String appointDatabase = new String(Files.readAllBytes(Paths.get("appointment.txt")));
                JSONObject appointJson = new JSONObject(appointDatabase.isEmpty() ? "{}" : appointDatabase);

                boolean feedbackUpdated = false;

                // Loop through the JSON to find the matching record
                for (String appointID : appointJson.keySet()) {
                    JSONArray appointArray = appointJson.getJSONArray(appointID);

                    for (int i = 0; i < appointArray.length(); i++) {
                        JSONObject appointData = appointArray.getJSONObject(i);

                        // Match the appointment details
                        if (appointData.getString("date").equals(date) &&
                            appointData.getString("time").equals(time)) {

                            // Determine user role and update the correct feedback
                            if (Details.userRole.equals("student") && 
                                appointData.getString("studentId").equals(Details.userId)) {
                                appointData.put("studentFeedback", feedbackInput);
                            } else if (Details.userRole.equals("lecturer") &&
                                       appointData.getString("lecturerId").equals(Details.userId)) {
                                appointData.put("lecturerFeedback", feedbackInput);
                            }
                            feedbackUpdated = true;
                            break;
                        }
                    }
                }

                if (feedbackUpdated) {
                    // Save updated JSON back to the file
                    Files.write(Paths.get("appointment.txt"), appointJson.toString(4).getBytes());
                    jTable1.setValueAt(feedbackInput, selectedRow, 4); // Update table visually
                    JOptionPane.showMessageDialog(this, "Feedback saved successfully!");
                } else {
                    JOptionPane.showMessageDialog(this, "Could not update feedback. Please try again.");
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error updating feedback.");
        }
    } else {
        JOptionPane.showMessageDialog(this, "Please select a row to leave feedback!");
    }
}

    private void updateFeedbackInFile(String date, String time, int column, String feedback) {
    try {
        String appointDatabase = new String(Files.readAllBytes(Paths.get("appointment.txt")));
        JSONObject appointJson = new JSONObject(appointDatabase.isEmpty() ? "{}" : appointDatabase);

        for (String appointID : appointJson.keySet()) {
            JSONArray appointArray = appointJson.getJSONArray(appointID);

            for (int i = 0; i < appointArray.length(); i++) {
                JSONObject appointData = appointArray.getJSONObject(i);

                if (appointData.getString("date").equals(date) &&
                    appointData.getString("time").equals(time)) {

                    if (Details.userRole.equals("lecturer") && column == 4) {
                        appointData.put("lecturerFeedback", feedback);
                    } else if (Details.userRole.equals("student") && column == 5) {
                        appointData.put("studentFeedback", feedback);
                    }
                }
            }
        }

        Files.write(Paths.get("appointment.txt"), appointJson.toString(4).getBytes());
        JOptionPane.showMessageDialog(this, "Feedback updated successfully!");
    } catch (IOException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Error updating feedback.");
    }
}

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(0, 102, 102));

        jLabel1.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Past Appointments");

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object[][] {},
            new String[] {
                "Name", "Date", "Time", "Duration", "Lecturer Feedback", "Student Feedback"
            }) {

                boolean[] canEdit = new boolean[] {
                    false, false, false, false, false, false
                };

                public boolean isCellEditable(int rowIndex, int columnIndex) {
                    // Column index 4 is Lecturer Feedback, Column index 5 is Student Feedback
                    if (Details.userRole.equals("lecturer") && columnIndex == 4) {
                        return true; // Allow editing Lecturer Feedback for lecturers
                    } else if (Details.userRole.equals("student") && columnIndex == 5) {
                        return true; // Allow editing Student Feedback for students
                    }
                    return false; // All other columns are not editable
                }
            });
            jScrollPane1.setViewportView(jTable1);

            jButton1.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 14)); // NOI18N
            jButton1.setText("Leave Feedback");
            jButton1.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    jButton1ActionPerformed(evt);
                }
            });

            jButton3.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 14)); // NOI18N
            jButton3.setText("Back");
            jButton3.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    jButton3ActionPerformed(evt);
                }
            });

            jButton2.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 14)); // NOI18N
            jButton2.setText("View Feedback");
            jButton2.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    jButton2ActionPerformed(evt);
                }
            });

            javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
            jPanel1.setLayout(jPanel1Layout);
            jPanel1Layout.setHorizontalGroup(
                jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                    .addGap(35, 35, 35)
                    .addComponent(jButton3)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel1)
                    .addGap(297, 297, 297))
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addGap(70, 70, 70)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 686, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addGap(186, 186, 186)
                            .addComponent(jButton1)
                            .addGap(176, 176, 176)
                            .addComponent(jButton2)))
                    .addContainerGap(72, Short.MAX_VALUE))
            );
            jPanel1Layout.setVerticalGroup(
                jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addGap(17, 17, 17)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel1)
                        .addComponent(jButton3))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 391, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 50, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jButton1)
                        .addComponent(jButton2))
                    .addGap(47, 47, 47))
            );

            javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
            getContentPane().setLayout(layout);
            layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE))
            );
            layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
            );

            pack();
        }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        leaveFeedbackActionPerformed();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // Check the userRole to decide where to navigate
        if ("student".equals(Details.userRole)) {
            // If user is a student, navigate to the student dashboard
            DashboardStu dashStu = new DashboardStu();
            dashStu.setVisible(true);
        } else if ("lecturer".equals(Details.userRole)) {
            // If user is a lecturer, navigate to the lecturer dashboard
            DashboardLect dashLect = new DashboardLect();
            dashLect.setVisible(true);
        }

    // Dispose the current window to go back to the appropriate dashboard
    this.dispose();

    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        int selectedRow = jTable1.getSelectedRow(); // Get the selected row index
    if (selectedRow != -1) { // Ensure a row is selected
        String name = jTable1.getValueAt(selectedRow, 0).toString(); // Name column
        String lecturerFeedback = jTable1.getValueAt(selectedRow, 4).toString(); // Lecturer Feedback column
        String studentFeedback = jTable1.getValueAt(selectedRow, 5).toString(); // Student Feedback column
        
        // Construct feedback details to display
        String feedbackDetails = "Name: " + name + "\n\n" +
                                 "Lecturer Feedback:\n" + lecturerFeedback + "\n\n" +
                                 "Student Feedback:\n" + studentFeedback;

        // Display feedback in a popup
        JOptionPane.showMessageDialog(this, feedbackDetails, "View Feedback", JOptionPane.INFORMATION_MESSAGE);
    } else {
        // Show a warning if no row is selected
        JOptionPane.showMessageDialog(this, "Please select a row to view feedback!", "No Selection", JOptionPane.WARNING_MESSAGE);
    }

    }//GEN-LAST:event_jButton2ActionPerformed
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> new Feedback().setVisible(true));
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Feedback.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Feedback.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Feedback.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Feedback.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Feedback().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables
}
