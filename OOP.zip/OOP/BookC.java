/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package OOP;

import org.json.JSONObject;
import org.json.JSONArray;
import javax.swing.*;
import java.io.IOException;
import javax.swing.table.DefaultTableModel;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


public class BookC extends javax.swing.JFrame { //Inheritance

// Encapsulation    
    private JFrame frame;
    private int currentPage = 0;
    private int slotsPerPage = 10;
    private List<JSONObject> availableSlots;
    private List<String> slotIDs;

    
    
    public BookC() {
        initComponents();
        loadAppointmentsData();
    }

    private void loadAppointmentsData() {
    try {
        // Read data from appointment.txt file , Abstraction
        String appointDatabase = new String(Files.readAllBytes(Paths.get("appointment.txt")));
        JSONObject appointJson = new JSONObject(appointDatabase.isEmpty() ? "{}" : appointDatabase);

        // List to store available slots (unscheduled appointments)
        availableSlots = new ArrayList<>();
        slotIDs = new ArrayList<>();

        // Get current system time
        java.time.LocalDateTime now = java.time.LocalDateTime.now();
        java.time.format.DateTimeFormatter dateFormatter = java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd");
        java.time.format.DateTimeFormatter timeFormatter = java.time.format.DateTimeFormatter.ofPattern("HH:mm");

        // Iterate over each key in the JSON object (appointment IDs)
        Iterator<String> appointKeys = appointJson.keys();

        while (appointKeys.hasNext()) {
            String appointID = appointKeys.next();
            JSONArray appointArray = appointJson.getJSONArray(appointID);

            // Iterate over the appointments in each array
            for (int i = 0; i < appointArray.length(); i++) {
                JSONObject appointData = appointArray.getJSONObject(i);

                // Only add appointments that are "unscheduled" and not expired
                if (appointData.getString("status").equals("unscheduled")) {
                    String slotDate = appointData.getString("date"); // Format: yyyy-MM-dd
                    String slotTime = appointData.getString("time"); // Format: HH:mm
                    
                    // Parse slot date and time
                    java.time.LocalDateTime slotDateTime = java.time.LocalDateTime.of(
                        java.time.LocalDate.parse(slotDate, dateFormatter),
                        java.time.LocalTime.parse(slotTime, timeFormatter)
                    );

                    // Check if the slot is still valid (not expired)
                    // If the date is today, check if the slot time is after the current time
                    if (!slotDateTime.isBefore(now) && !(slotDateTime.toLocalDate().isEqual(now.toLocalDate()) && slotDateTime.toLocalTime().isBefore(now.toLocalTime()))) {
                        availableSlots.add(appointData);
                        slotIDs.add(appointID); // Store the appointment ID for reference
                    }
                }
            }
        }

        // Update the table to show the available slots
        updateTable();

    } catch (IOException e) {
        System.out.println("Error: " + e);
        JOptionPane.showMessageDialog(this, "Error reading the appointments file.");
    }
}



    
   private void updateTable() {
    // Clear existing rows in the table
    DefaultTableModel tableModel = (DefaultTableModel) slotsTable.getModel();
    tableModel.setRowCount(0);

    // Calculate the range for the current page
    int start = currentPage * slotsPerPage;
    int end = Math.min(start + slotsPerPage, availableSlots.size());

    // Loop through the available slots and add them to the table model
    for (int i = start; i < end; i++) {
        JSONObject slot = availableSlots.get(i);
        tableModel.addRow(new Object[] {
            slot.getString("lecturerName"),
            slot.getString("duration"),
            slot.getString("date"),
            slot.getString("time")
        });
    }

    // Update the page label
    pageLabel.setText(String.format("Page %d of %d", currentPage + 1, 
        (int) Math.ceil((double) availableSlots.size() / slotsPerPage)));
}

  
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        Title = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        slotsTable = new javax.swing.JTable();
        jButton3 = new javax.swing.JButton();
        pageLabel = new javax.swing.JLabel();
        jButton4 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(0, 102, 102));
        jPanel1.setFont(new java.awt.Font("Microsoft YaHei Light", 0, 12)); // NOI18N

        Title.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 36)); // NOI18N
        Title.setText("BOOK AN APPOINTMENT");

        jButton1.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 14)); // NOI18N
        jButton1.setText("Previous");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 14)); // NOI18N
        jButton2.setText("Next");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        slotsTable.setModel(new DefaultTableModel(
            new Object[][] {},  // Start with no data
            new String[] {"Lecturer Name", "Duration", "Date", "Time"} ));
    jScrollPane1.setViewportView(slotsTable);

    jButton3.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 18)); // NOI18N
    jButton3.setText("Book");
    jButton3.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            jButton3ActionPerformed(evt);
        }
    });

    pageLabel.setText("jLabel1");

    jButton4.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 14)); // NOI18N
    jButton4.setText("Back");
    jButton4.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            jButton4ActionPerformed(evt);
        }
    });

    javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
    jPanel1.setLayout(jPanel1Layout);
    jPanel1Layout.setHorizontalGroup(
        jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
            .addGap(18, 18, 18)
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addComponent(Title)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton4))
                .addComponent(jScrollPane1)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                    .addGap(60, 60, 60)
                    .addComponent(jButton1)
                    .addGap(387, 387, 387)
                    .addComponent(pageLabel)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 419, Short.MAX_VALUE)
                    .addComponent(jButton2)))
            .addGap(60, 60, 60))
        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
            .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jButton3)
            .addGap(532, 532, 532))
    );
    jPanel1Layout.setVerticalGroup(
        jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(jPanel1Layout.createSequentialGroup()
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addGap(21, 21, 21)
                    .addComponent(Title)
                    .addGap(18, 18, 18))
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jButton4)
                    .addGap(29, 29, 29)))
            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGap(38, 38, 38)
            .addComponent(jButton3)
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 42, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(jButton1)
                .addComponent(pageLabel)
                .addComponent(jButton2))
            .addGap(39, 39, 39))
    );

    javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
    getContentPane().setLayout(layout);
    layout.setHorizontalGroup(
        layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    );
    layout.setVerticalGroup(
        layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    );

    pack();
    setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    
    
    // Next button
    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        if (currentPage < (int) Math.ceil((double) availableSlots.size() / slotsPerPage) - 1) {
        currentPage++;
        updateTable();
    } else {
        JOptionPane.showMessageDialog(frame, "This is the last page.");
    }
    }//GEN-LAST:event_jButton2ActionPerformed

    // Previous Button
    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        if (currentPage > 0) {
        currentPage--;
        updateTable();
    } else {
        JOptionPane.showMessageDialog(frame, "This is the first page.");
    }
    }//GEN-LAST:event_jButton1ActionPerformed

    // Book button
    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
    int selectedRow = slotsTable.getSelectedRow();

    if (selectedRow != -1) {
        JSONObject selectedSlot = availableSlots.get(currentPage * slotsPerPage + selectedRow);
        String slotID = slotIDs.get(currentPage * slotsPerPage + selectedRow);

        try {
            String appointDatabase = new String(Files.readAllBytes(Paths.get("appointment.txt")));
            JSONObject appointJson = new JSONObject(appointDatabase.isEmpty() ? "{}" : appointDatabase);

            JSONArray appointArray = appointJson.getJSONArray(slotID);

            // Validate for duplicate booking
            if (isDuplicateBooking(appointJson, Details.userId, selectedSlot)) {
                JOptionPane.showMessageDialog(frame, "You have already booked this slot or a conflicting slot exists.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Proceed to update the slot
             for (int i = 0; i < appointArray.length(); i++) {
            JSONObject slot = appointArray.getJSONObject(i);
            // Match the selected slot by date, time, and status
            if (slot.getString("date").equals(selectedSlot.getString("date")) &&
                slot.getString("time").equals(selectedSlot.getString("time")) &&
                slot.getString("status").equals("unscheduled")) {

            // Update the slot details
                slot.put("status", "requested");
                slot.put("studentId", Details.userId);
                slot.put("studentName", Details.username);

            // Replace the slot in the array
            appointArray.put(i, slot);
            break; // Exit the loop once the slot is updated
        }
    }

            // Save updated data to the file
            try (FileWriter file = new FileWriter("appointment.txt")) {
                file.write(appointJson.toString(4));
                file.flush();
            }

            JOptionPane.showMessageDialog(frame, "Slot successfully requested!");
            loadAppointmentsData(); // Refresh the table after booking
        } catch (IOException e) {
            JOptionPane.showMessageDialog(frame, "Error updating appointment: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    } else {
        JOptionPane.showMessageDialog(frame, "Please select a slot first.");
    }
}

    // Helper function to check for duplicate or overlapping slots
    private boolean isDuplicateBooking(JSONObject appointJson, String studentId, JSONObject selectedSlot) {
        for (String key : appointJson.keySet()) {
            JSONArray appointArray = appointJson.getJSONArray(key);
            for (int i = 0; i < appointArray.length(); i++) {
                JSONObject slot = appointArray.getJSONObject(i);
                if (slot.has("studentId") && slot.getString("studentId").equals(studentId)) {
                    // Check for the same slot or time overlap
                    if (slot.getString("date").equals(selectedSlot.getString("date")) && 
                        slot.getString("time").equals(selectedSlot.getString("time"))) {
                        return true; // Duplicate slot booking
                    }
                }
            }
        }
        return false;
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        DashboardStu dashstu = new DashboardStu();
        dashstu.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton4ActionPerformed
    
    /**
     * @param args the command line arguments
     */
    
    
    
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(BookC.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(BookC.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(BookC.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(BookC.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new BookC().setVisible(true);
            }
        });
    }


// // Mock global variables for testing
class Global {
    public static String currentUserRole;
    public static String userID;
    public static String username;
}
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Title;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel pageLabel;
    private javax.swing.JTable slotsTable;
    // End of variables declaration//GEN-END:variables
}
