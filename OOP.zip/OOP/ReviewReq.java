/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package OOP;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author user
 */
public class ReviewReq extends javax.swing.JFrame {
    private int currentPage = 0;
    private int slotsPerPage = 10;
    private List<JSONObject> availableSlots;
    private List<String> slotIDs;
    /**
     * Creates new form ReviewReq
     */
    public ReviewReq() {
        initComponents();
        loadAppointmentsData();
    }
    
    private void loadAppointmentsData() {
    try {
        // Read data from appointment.txt file
        String appointDatabase = new String(Files.readAllBytes(Paths.get("appointment.txt")));
        JSONObject appointJson = new JSONObject(appointDatabase.isEmpty() ? "{}" : appointDatabase);

        availableSlots = new ArrayList<>();
        slotIDs = new ArrayList<>();

        // Iterate over each key in the JSON object (appointment IDs)
        Iterator<String> appointKeys = appointJson.keys();

        while (appointKeys.hasNext()) {
            String appointID = appointKeys.next();
            JSONArray appointArray = appointJson.getJSONArray(appointID);

            // Iterate over the appointments in each array
            for (int i = 0; i < appointArray.length(); i++) {
                JSONObject appointData = appointArray.getJSONObject(i);

                // Only show requested slots + make sure it is for that specific lecturer
                if (appointData.getString("status").equals("requested") && appointData.getString("lecturerId").equals(Details.userId)) {
                    availableSlots.add(appointData);
                    slotIDs.add(appointID); // Store the appointment ID for reference
                }
            }
        }

        // Update the table to show the available slots
        updateTable();

    } catch (IOException e) {
        System.out.println("Error: " + e);
        JOptionPane.showMessageDialog(this, "Error reading the appointments file.");
    }
}
    
    private void updateTable() {
    // Clear existing rows in the table
    DefaultTableModel tableModel = (DefaultTableModel) jTable1.getModel();
    tableModel.setRowCount(0);

    // Calculate the range for the current page
    int start = currentPage * slotsPerPage;
    int end = Math.min(start + slotsPerPage, availableSlots.size());

    // Loop through the available slots and add them to the table model
    for (int i = start; i < end; i++) {
        JSONObject slot = availableSlots.get(i);
        tableModel.addRow(new Object[] {
            slot.getString("studentName"),
            slot.getString("duration"),
            slot.getString("date"),
            slot.getString("time")
        });
    }
}
    
   private void updateAppointmentStatus(String newStatus) {
    int selectedRow = jTable1.getSelectedRow();
    if (selectedRow == -1) {
        JOptionPane.showMessageDialog(this, "Please select an appointment from the table.");
        return;
    }

    try {
        // Read the current appointment data
        String filePath = "appointment.txt";
        File file = new File(filePath);

        // Ensure the file exists, if not, create it
        if (!file.exists()) {
            file.createNewFile();
            JOptionPane.showMessageDialog(this, "No appointments found. The file has been created.", 
                    "Info", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        // Load the JSON data from the file
        String appointData = new String(Files.readAllBytes(Paths.get(filePath)));
        JSONObject appointJson = new JSONObject(appointData.isEmpty() ? "{}" : appointData);

        // Get the appointment ID and corresponding data
        String selectedID = slotIDs.get(currentPage * slotsPerPage + selectedRow);
        JSONArray appointArray = appointJson.getJSONArray(selectedID);

        // Create a new JSONArray to store only the selected appointment
        JSONArray updatedArray = new JSONArray();
        boolean statusUpdated = false;

        for (int i = 0; i < appointArray.length(); i++) {
            JSONObject appointObj = appointArray.getJSONObject(i);

            // Check if this is the selected appointment
            if (appointObj.getString("lecturerId").equals(Details.userId)
                    && appointObj.getString("lecturerName").equals(Details.username)) {
                
                // Update the appointment status
                appointObj.put("status", newStatus);
                updatedArray.put(appointObj); // Add only the matching appointment
                statusUpdated = true;
                break; // Only include the matching appointment, exit loop
            }
        }

        if (statusUpdated) {
            // Replace the original array with the updated array in the JSON object
            appointJson.put(selectedID, updatedArray);

            // Write the updated JSON back to the file
            Files.write(Paths.get(filePath), appointJson.toString(4).getBytes());

            // Reload data and update the table
            JOptionPane.showMessageDialog(this, "Appointment status updated to: " + newStatus);
            loadAppointmentsData();
        } else {
            JOptionPane.showMessageDialog(this, "No matching appointment found for the selected student.");
        }
    } catch (IOException e) {
        JOptionPane.showMessageDialog(this, "Error updating appointment status: " + e.getMessage());
    }
   }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(0, 102, 102));
        jPanel1.setForeground(new java.awt.Color(0, 102, 102));
        jPanel1.setPreferredSize(new java.awt.Dimension(625, 462));

        jButton1.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 14)); // NOI18N
        jButton1.setText("Back");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        jButton2.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 14)); // NOI18N
        jButton2.setText("Approve");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setFont(new java.awt.Font("Microsoft YaHei UI Light", 1, 14)); // NOI18N
        jButton3.setText("Reject");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton1)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 566, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(37, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(134, 134, 134)
                .addComponent(jButton2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton3)
                .addGap(139, 139, 139))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addComponent(jButton1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 298, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton2)
                    .addComponent(jButton3))
                .addGap(0, 40, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        DashboardLectTS dashlect = new DashboardLectTS();
        dashlect.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        updateAppointmentStatus("Rejected");
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        updateAppointmentStatus("Booked");
    }//GEN-LAST:event_jButton2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ReviewReq.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ReviewReq.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ReviewReq.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ReviewReq.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ReviewReq().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables
}
