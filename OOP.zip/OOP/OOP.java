package OOP;
import javax.swing.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import org.json.JSONObject;
import org.json.JSONArray;
import java.io.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class OOP {
    
    public static void main(String[] args) {
        updatePastAppointments();
        MainM mainMenu = new MainM();
        mainMenu.setVisible(true);
    }
    
    public static void updatePastAppointments() {
    try {
        File file = new File("appointment.txt");
        if (!file.exists()) {
            file.createNewFile();
            return; // No appointments to update
        }

        // Read the content of appointment.txt
        String appointDatabase = new String(Files.readAllBytes(Paths.get("appointment.txt")));
        JSONObject appointJson = new JSONObject(appointDatabase.isEmpty() ? "{}" : appointDatabase);
        LocalDate today = LocalDate.now(); // Current date
        LocalTime now = LocalTime.now(); // Current time

        // Iterate over all appointments
        for (String appointID : appointJson.keySet()) {
            JSONArray appointArray = appointJson.getJSONArray(appointID);

            for (int i = 0; i < appointArray.length(); i++) {
                JSONObject appointData = appointArray.getJSONObject(i);

                // Retrieve necessary fields
                String status = appointData.getString("status");
                String dateStr = appointData.getString("date");
                String timeStr = appointData.getString("time"); // Start time as string
                String durationStr = appointData.getString("duration"); // e.g., "2 hours"

                LocalDate appointDate = LocalDate.parse(dateStr, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
                LocalTime startTime = LocalTime.parse(timeStr, DateTimeFormatter.ofPattern("HH:mm"));
                int durationHours = Integer.parseInt(durationStr.split(" ")[0]); // Extract "2" from "2 hours"
                LocalTime endTime = startTime.plusHours(durationHours); // Calculate end time

                String studentName = appointData.optString("studentName", ""); // Optional studentName field

                // Condition 1: "Booked" → "Completed" if the appointment has ended
                if (status.equalsIgnoreCase("Booked")) {
                    if (appointDate.isBefore(today) || 
                        (appointDate.isEqual(today) && now.isAfter(endTime))) {
                        if (!studentName.isEmpty()) { 
                            appointData.put("status", "Completed");
                        }
                    }
                }

                // Condition 2: "Unscheduled" → "Expired" if the date has passed
                if (status.equalsIgnoreCase("Unscheduled") && appointDate.isBefore(today)) {
                    appointData.put("status", "Expired");
                }
            }
        }

        // Write the updated data back to appointment.txt
        Files.write(Paths.get("appointment.txt"), appointJson.toString(4).getBytes());
        System.out.println("Past appointments updated successfully!");

    } catch (IOException e) {
        System.out.println("Error updating appointments: " + e.getMessage());
    }
}

    
    public static void Register(String username, String password){
        try{ 
            File test = new File("user.txt");
            if (!test.exists()){
                test.createNewFile();
            }
            String userData = new String(Files.readAllBytes(Paths.get("user.txt")));
            JSONObject content = new JSONObject(userData.isEmpty() ? "{}" : userData);
            
            
        } catch (IOException e){
            System.out.println("Error message: " + e.getMessage());
        }
    }

    public static boolean Login(String username, String password) {     
        try {
           
            String userDatabase = new String(Files.readAllBytes(Paths.get("user.txt")));
            JSONObject content = new JSONObject(userDatabase.isEmpty() ? "{}" : userDatabase);
            if (content.has(username)) {
                JSONArray userArray = content.getJSONArray(username);
                JSONObject userInfo = userArray.getJSONObject(0); 

                if (userInfo.getString("password").equals(password)) {
                    return true;
                } else {
                    JOptionPane.showMessageDialog(null, "Invalid password.");
                }
            } else {
                JOptionPane.showMessageDialog(null, "User not found.");
            }

        } catch (IOException e) {
            System.out.println("Error message: " + e.getMessage());
        }
        return false;
}
}